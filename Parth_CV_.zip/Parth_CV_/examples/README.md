# Curriculum Vitae
This project is originally by [Byungjin Park](https://github.com/posquit0). I have taken his free to use project: [Awesome-CV](https://github.com/posquit0/Awesome-CV), for my personal use.
